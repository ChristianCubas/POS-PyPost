import openpyxl
import tkinter as tk
import psycopg2
from tkinter import ttk, messagebox

conexion = psycopg2.connect(user='postgres',
                            password='christiansql',
                            host='127.0.0.1',
                            port='5432',
                            database='POS Python')


class producto():
    def __init__(self, id, producto, codigo, cantidad, descuento, devolucion):
        self.id = id
        self.producto = producto
        self.codigo = codigo
        self.cantidad = cantidad
        self.descuento = descuento
        self.devolucion = devolucion
        self.lista = []

    @property
    def id(self):
        return self._id

    @id.setter
    def id(self, nuevo):
        self._id = nuevo

    @property
    def producto(self):
        return self._producto

    @producto.setter
    def producto(self, nuevo):
        self._producto = nuevo

    @property
    def codigo(self):
        return self._codigo

    @codigo.setter
    def codigo(self, nuevo):
        self._codigo = nuevo

    @property
    def cantidad(self):
        return self._cantidad

    @cantidad.setter
    def cantidad(self, nuevo):
        self._cantidad = nuevo

    @property
    def descuento(self):
        return self._descuento

    @descuento.setter
    def descuento(self, nuevo):
        self._descuento = nuevo

    @property
    def devolucion(self):
        return self._devolucion

    @devolucion.setter
    def devolucion(self, nuevo):
        self._devolucion = nuevo

    @property
    def mostrar_lista(self):
        return self.lista

    @mostrar_lista.setter
    def cambiar_lista(self, object):
        self.lista.append(object)


def reporte_elaborar():
    class Reporte(tk.Tk):
        def __init__(self):
            super().__init__()
            self.title("Reporte")
            centrado_horiz = self.winfo_screenwidth() / 2.8
            centrado_vert = self.winfo_screenheight() / 5.4
            self.geometry("400x400+" + str(round(centrado_horiz)) + "+" + str(round(centrado_vert)))

            def espaciado(a):
                espacio = ttk.Label(self, text="")
                espacio.grid(row=a, column=0, sticky="NSWE")

            def mostrar_texto(info, a):
                texto = ttk.Label(self, text=info)
                texto.grid(row=a, column=0, sticky="NSWE")

            def crear_boton(informacion, a, funcion):
                boton = ttk.Button(self, text=informacion, command=funcion)
                boton.grid(row=a, column=0, sticky="NSWE")

            espaciado(0)
            try:
                with conexion:
                    with conexion.cursor() as cursor:
                        cursor.execute("SELECT * FROM inventario")
                        registro = cursor.fetchall()
                        pos = 1
                        for i in registro:
                            mostrar_texto(i, pos)
                            espaciado(pos + 1)
                            pos += 1
            except Exception as e:
                messagebox.showinfo(self, "Ha ocurrido un error")
            finally:
                conexion.close()

            for dato in registro:
                product = producto(dato[0], dato[1], dato[2], dato[3], dato[4], dato[5])
                product.lista = product

            def reporte_excel():
                crear_archivo = openpyxl.Workbook()
                sheet = crear_archivo.active
                sheet["A1"] = 'id'
                sheet["B1"] = 'Producto'
                sheet["C1"] = 'Codigo del producto'
                sheet["D1"] = 'Cantidad'
                sheet["E1"] = 'Descuento'
                sheet["F1"] = 'Devolucion'

                for i, product in enumerate(producto.mostrar_lista):
                    sheet["A" + str(i + 2)] = product.id
                    sheet["B" + str(i + 2)] = product.producto
                    sheet["C" + str(i + 2)] = product.codigo
                    sheet["D" + str(i + 2)] = product.cantidad
                    sheet["E" + str(i + 2)] = product.descuento
                    sheet["F" + str(i + 2)] = product.devolucion

                crear_archivo.save("Reporte POS Python.xlsx")

            crear_boton("Crear Reporte Excel", pos + 1, reporte_excel)

    app = Reporte()
    app.mainloop()