import tkinter as tk
from tkinter import ttk, messagebox
import psycopg2

conexion = psycopg2.connect(user='postgres',
                            password='christiansql',
                            host='127.0.0.1',
                            port='5432',
                            database='POS Python')


def ventas():
    class generar_venta(tk.Tk):
        def __init__(self):
            super().__init__()
            self.title("Generar venta")
            ancho_centrar = self.winfo_screenwidth() / 2.8
            altura_centrar = self.winfo_screenheight() / 5.4
            self.geometry("500x400+" + str(round(ancho_centrar)) + "+" + str(round(altura_centrar)))

            entrada = ttk.Entry(self, width=20)
            entrada.grid(row=0, column=0, sticky="NSWE")
            entrada.insert(0, "Ingrese el nombre del producto")

            def ingresar_compra():
                try:
                    with conexion:
                        with conexion.cursor() as cursor:
                            cursor.execute("SELECT producto FROM inventario")
                            registro = cursor.fetchone()
                            for i in registro:
                                if entrada.get() == i:
                                    sentencia = "SELECT precio FROM inventario WHERE producto=%s"
                                    cursor.execute(sentencia, (i,))
                                    precio = cursor.fetchone()[0]
                                    textarea.insert(tk.END, str(i) + " => S/." + str(precio) + "\n")
                except Exception as e:
                    messagebox.showinfo("Error", "Ha ocurrido un error")
                finally:
                    conexion.close()

            boton = ttk.Button(self, text="Ingresar Producto", command=ingresar_compra)
            boton.grid(row=0, column=1, sticky="NSWE")
            textarea = tk.Text(self, width=10, height=30)
            textarea.grid(row=1, column=0, sticky="NSWE")

            self.columnconfigure(0, weight=5)
            self.columnconfigure(1, weight=1)

    app = generar_venta()
    app.mainloop()
