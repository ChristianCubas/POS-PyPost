import tkinter as tk
from tkinter import ttk,messagebox
import psycopg2

conexion = psycopg2.connect(user='postgres',
                            password='christiansql',
                            host='127.0.0.1',
                            port='5432',
                            database='POS Python')

def estado_devolucion():
    class devoluciones(tk.Tk):
        def __init__(self):
            super().__init__()
            self.title("Devoluciones")
            width_center = self.winfo_screenwidth() / 2.8
            height_center = self.winfo_screenheight() / 5.4
            self.geometry("400x400+" + str(round(width_center)) + "+" + str(round(height_center)))

            def generar_espacio(a):
                espaciado = ttk.Label(self, text="")
                espaciado.grid(row=a, column=0, sticky="NSWE")

            generar_espacio(0)

            def escribir_info(informacion, a):
                info = ttk.Label(self, text=informacion)
                info.grid(row=a, column=0, sticky="NSWE")

            try:
                with conexion:
                    with conexion.cursor() as cursor:
                        cursor.execute("SELECT id,producto,devolucion FROM inventario")
                        registro = cursor.fetchall()
                        pos = 1
                        for i in registro:
                            escribir_info(i, pos)
                            generar_espacio(pos + 1)
                            pos += 1
            except Exception as e:
                messagebox.showinfo(self, "Ha ocurrido un error")
            finally:
                conexion.close()

    app = devoluciones()
    app.mainloop()
