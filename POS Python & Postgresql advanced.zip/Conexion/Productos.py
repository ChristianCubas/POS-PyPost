import tkinter as tk
from tkinter import ttk,messagebox
import psycopg2

conexion = psycopg2.connect(user='postgres',
                            password='christiansql',
                            host='127.0.0.1',
                            port='5432',
                            database='POS Python')

def productos_esquema():
    class productos(tk.Tk):
        def __init__(self):
            super().__init__()
            self.title("Productos")
            centrar_ancho = self.winfo_screenwidth() / 2.8
            centrar_altura = self.winfo_screenheight() / 5.4
            self.geometry("400x400+" + str(round(centrar_ancho)) + "+" + str(round(centrar_altura)))

            def producto(nombre, a):
                texto = ttk.Label(self, text=nombre)
                texto.grid(row=a, column=0, sticky="NSWE")

            def espacio(a):
                text = ttk.Label(self, text="")
                text.grid(row=a, column=0, sticky="NSWE")

            espacio(0)
            try:
                with conexion:
                    with conexion.cursor() as cursor:
                        cursor.execute("SELECT id,producto FROM inventario")
                        registro = cursor.fetchall()
                        pos = 1
                        for i in registro:
                            producto(i, pos)
                            espacio(pos + 1)
                            pos += 1
            except Exception as e:
                messagebox.showinfo(self, "Ha ocurrido un error")
            finally:
                conexion.close()

    app = productos()
    app.mainloop()