import tkinter as tk
import psycopg2
from tkinter import ttk,messagebox
from GenerarVenta import ventas
from Inventario import inventario_general
from Productos import productos_esquema
from Descuentos import descuentos_aplicables
from Devoluciones import estado_devolucion
from GenerarReporte import reporte_elaborar

conexion = psycopg2.connect(user='postgres',
                            password='christiansql',
                            host='127.0.0.1',
                            port='5432',
                            database='POS Python')

def ventana_principal():
    class ventana(tk.Tk):
        def __init__(self):
            super().__init__()
            self.title("POS Python y Postgresql")
            ancho = self.winfo_screenwidth() / 2.8
            altura = self.winfo_screenheight() / 5.4
            self.geometry("400x400+" + str(round(ancho)) + "+" + str(round(altura)))
            titulo = ttk.Label(self, text="Seleccione la operacion que desea realizar")
            titulo.grid(row=0, column=0, sticky="NSWE")

            def espacio(a):
                espacio = ttk.Label(self, text="")
                espacio.grid(row=a, column=0, sticky="NSWE")

            espacio(1)

            def crear_boton(texto, funcion, a):
                boton = ttk.Button(self, text=texto, command=funcion)
                boton.grid(row=a, column=0, sticky="NSWE")

            crear_boton("Generar venta", ventas, 2)
            espacio(3)
            crear_boton("Ver inventario", inventario_general, 4)
            espacio(5)
            crear_boton("Ver catalogo de productos", productos_esquema, 6)
            espacio(7)
            crear_boton("Ver descuentos disponibles", descuentos_aplicables, 8)
            espacio(9)
            crear_boton("Visualizar devoluciones efectuadas", estado_devolucion, 10)
            espacio(11)
            crear_boton("Generar reporte", reporte_elaborar, 12)
            self.columnconfigure(0, weight=3)

    app = ventana()
    app.mainloop()

class seguridad(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Modulo de Seguridad")
        ancho_ = self.winfo_screenwidth() / 2.8
        altura_ = self.winfo_screenheight() / 5.4
        self.geometry("400x400+" + str(round(ancho_)) + "+" + str(round(altura_)))
        titulo_usuario = ttk.Label(self,text="Nombre")
        titulo_usuario.grid(row=0,column=0,sticky="NSWE")
        usuario = ttk.Entry(self,width=20)
        usuario.grid(row=0,column=1,sticky="NSWE")
        usuario.insert(0,"Ingrese su nombre de usuario")
        titulo_contraseña = ttk.Label(self,text="Contraseña")
        titulo_contraseña.grid(row=1,column=0,sticky="NSWE")
        entrada_contraseña = ttk.Entry(self,width=20,show="*")
        entrada_contraseña.grid(row=1,column=1,sticky="NSWE")
        def comprobar():
            try:
                with conexion:
                    with conexion.cursor() as cursor:
                        cursor.execute("SELECT nombre FROM trabajadores")
                        registro = cursor.fetchall()
                        for i in registro:
                            if usuario.get() == i:
                                cursor.execute("SELECT contraseña FROM trabajadores WHERE nombre=%s", (str(i),))
                                registro2 = cursor.fetchone()
                                print(registro2)
                                if entrada_contraseña.get() == registro2[0][0]:
                                    print("Es trabajador")
                                    button = ttk.Button(self, text="Ingresar", command=ventana_principal)
                                    button.grid(row=3, column=0, sticky="NSWE")
            except Exception as e:
                messagebox.showinfo("Error","Ha ocurrido un error")
            finally:
                conexion.close()

        btn_valida = ttk.Button(self, text="Comprobar", command=comprobar)
        btn_valida.grid(row=2, column=0, sticky="NSWE")

        self.columnconfigure(0,weight=3)
        self.columnconfigure(1,weight=3)

if __name__ == '__main__':
    aplicacion = seguridad()
    aplicacion.mainloop()
    ventana_principal()