import tkinter as tk
from tkinter import ttk,messagebox
import psycopg2

conexion = psycopg2.connect(user='postgres',
                            password='christiansql',
                            host='127.0.0.1',
                            port='5432',
                            database='POS Python')

def descuentos_aplicables():
    class descuentos(tk.Tk):
        def __init__(self):
            super().__init__()
            self.title("Descuentos")
            centrar_horizontal = self.winfo_screenwidth() / 2.8
            centrar_vertical = self.winfo_screenheight() / 5.4
            self.geometry("400x400+" + str(round(centrar_horizontal)) + "+" + str(round(centrar_vertical)))

            def espaciado(a):
                espaciado = ttk.Label(self, text="")
                espaciado.grid(row=a, column=0, sticky="NSWE")

            def informacion(info, a):
                texto = ttk.Label(self, text=info)
                texto.grid(row=a, column=0, sticky="NSWE")

            espaciado(0)
            try:
                with conexion:
                    with conexion.cursor() as cursor:
                        cursor.execute("SELECT id,producto,descuento FROM inventario")
                        registro = cursor.fetchall()
                        position = 1
                        for i in registro:
                            informacion(i, position)
                            espaciado(position + 1)
                            position += 1
            except Exception as e:
                messagebox.showinfo(self, "Ha ocurrido un error")
            finally:
                conexion.close()

    app = descuentos()
    app.mainloop()