import tkinter as tk
from tkinter import ttk, messagebox
import psycopg2

conexion = psycopg2.connect(user='postgres',
                            password='christiansql',
                            host='127.0.0.1',
                            port='5432',
                            database='POS Python')

def inventario_general():
    class inventario(tk.Tk):
        def __init__(self):
            super().__init__()
            self.title("Visualizar Inventario")
            ancho_centrar = self.winfo_screenwidth() / 2.8
            altura_centrar = self.winfo_screenheight() / 5.4
            self.geometry("400x400+" + str(round(ancho_centrar)) + "+" + str(round(altura_centrar)))

            def espacio(a):
                espacio = ttk.Label(self, text="")
                espacio.grid(row=a, column=0)

            espacio(0)

            def productos(texto, a):
                texto = ttk.Label(self, text=texto)
                texto.grid(row=a, column=0, sticky="NSWE")

            def entrada(a):
                entrada = ttk.Entry(self,width=20)
                entrada.grid(row=a,column=1,sticky="NSWE")

            def titulo(texto,a):
                titulo = ttk.Label(self,text=texto)
                titulo.grid(row=a,column=0,sticky="NSWE")

            a = 1

            try:
                with conexion:
                    with conexion.cursor() as cursor:
                        cursor.execute("SELECT producto,cantidad FROM inventario")
                        registro = cursor.fetchall()
                        for i in registro:
                            productos(i, a)
                            espacio(a + 1)
                            a += 1
            except Exception as e:
                messagebox.showinfo(self, "Ha ocurrido un error")
            finally:
                conexion.close()

            titulo("Producto",(a+1))
            entrada(a+1)
            titulo("Codigo",(a+2))
            entrada(a+2)
            titulo("Cantidad",(a+3))
            entrada(a+3)
            titulo("Descuento",(a+4))
            entrada(a+4)
            titulo("Devolucion",(a+5))
            entrada(a+5)

            def agregar_producto():
                try:
                    with conexion:
                        with conexion.cursor() as cursor:
                            g=a
                            m = entrada(a + 1).get()
                            b = entrada(a + 2).get()
                            c = entrada(a + 3).get()
                            d = entrada(a + 4).get()
                            f = entrada(a + 5).get()

                            cursor.execute("INSERT INTO inventario(id,producto,codigo,cantidad,descuento,devolucion) VALUES (%s,%s,&d,%d,%s)",(g,m, b, c, d, f))
                            registrar = cursor.fetchall()
                            print(registrar)
                            print("Registrado")
                            messagebox.showinfo("Sistema", "Se registro exitosamente el nuevo producto")
                except Exception as e:
                    messagebox.showinfo("Error","Ha ocurrido un error")
                finally:
                    conexion.close()

            boton = ttk.Button(self,text="Agregar producto",command=agregar_producto)
            boton.grid(row=(a+7),column=0,sticky="NSWE")

    app = inventario()
    app.mainloop()
